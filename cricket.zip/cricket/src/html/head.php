<?php include 'session.php';?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cricket Team</title>
  <link rel="shortcut icon" type="image/png" href="../assets/images/logos/stump.png" />
  <link rel="stylesheet" href="../assets/css/styles.min.css" />
</head>